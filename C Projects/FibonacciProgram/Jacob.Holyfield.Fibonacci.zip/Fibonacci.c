/**********************************************
File Name = Fibonacci.c
Authors = Jacob Holyfield
Edited On = 9/21/2018
Description = A Program to ask how many terms of Fibonacci and print it out
Compiler Command = gcc -Wall -Wextra -ansi -pedantic -O -o Fibonacci Fibonacci.c
**********************************************/
#include <stdio.h>

/*Main Program*/
int main() 
{
	/*Init Vars*/
	int inputTermsOfFib = 0;
	int counter = 3;
	int Fn = 0;
	int Fn1 = 1;
	int Fn2 = 0;
	
	/*Get num of digits user wants*/
	printf("\nEnter the number of digits of Fibonacci : ");
	scanf("%i", &inputTermsOfFib);
	
	/*Print first 2 digits*/
	printf("\n%i, %i, ", Fn2, Fn1);
	
	while(counter <= inputTermsOfFib){
		/*calculate and print current term*/
		Fn = Fn1 + Fn2;
		printf("%i, ", Fn);
		
		/*Set vars so next time it is the right number*/
		Fn2 = Fn1;
		Fn1 = Fn;
		counter += 1;
	}
	
	return 0;
}